package com.example.sunbase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SunbaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
